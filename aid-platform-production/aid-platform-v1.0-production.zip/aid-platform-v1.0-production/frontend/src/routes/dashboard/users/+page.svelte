<script lang="ts">
	import { pb } from '$lib/api';
	import { onMount } from 'svelte';
	import { t } from 'svelte-i18n';

	interface User {
		id: string;
		email: string;
		name: string;
		mobile?: string;
		role: string;
		verified: boolean;
		created: string;
		updated: string;
	}

	let users: User[] = [];
	let loading = true;
	let error = '';
	let showModal = false;
	let editingUser: User | null = null;
	
	// Form fields
	let formEmail = '';
	let formName = '';
	let formMobile = '';
	let formRole = 'volunteer';
	let formPassword = '';
	let formPasswordConfirm = '';

	const roles = [
		{ value: 'admin', label: 'Admin' },
		{ value: 'monitor', label: 'Monitor' },
		{ value: 'volunteer', label: 'Volunteer' }
	];

	onMount(async () => {
		await loadUsers();
	});

	async function loadUsers() {
		try {
			loading = true;
			error = '';
			const records = await pb.collection('users').getFullList({
				sort: '-created'
			});
			users = records as User[];
		} catch (err: any) {
			error = err.message || 'Failed to load users';
			console.error('Error loading users:', err);
		} finally {
			loading = false;
		}
	}

	function openAddModal() {
		editingUser = null;
		formEmail = '';
		formName = '';
		formMobile = '';
		formRole = 'volunteer';
		formPassword = '';
		formPasswordConfirm = '';
		showModal = true;
	}

	function openEditModal(user: User) {
		editingUser = user;
		formEmail = user.email;
		formName = user.name || '';
		formMobile = user.mobile || '';
		formRole = user.role;
		formPassword = '';
		formPasswordConfirm = '';
		showModal = true;
	}

	function closeModal() {
		showModal = false;
		editingUser = null;
	}

	async function saveUser() {
		try {
			error = '';

			if (!formEmail || !formRole) {
				error = 'Email and role are required';
				return;
			}

			if (!editingUser && !formPassword) {
				error = 'Password is required for new users';
				return;
			}

			if (formPassword && formPassword.length < 8) {
				error = 'Password must be at least 8 characters';
				return;
			}

			if (formPassword && formPassword !== formPasswordConfirm) {
				error = 'Passwords do not match';
				return;
			}

			const data: any = {
				email: formEmail,
				name: formName,
				mobile: formMobile,
				role: formRole,
				emailVisibility: true,
				verified: true
			};

			if (formPassword) {
				data.password = formPassword;
				data.passwordConfirm = formPasswordConfirm;
			}

			if (editingUser) {
				// Update existing user
				await pb.collection('users').update(editingUser.id, data);
			} else {
				// Create new user
				await pb.collection('users').create(data);
			}

			closeModal();
			await loadUsers();
		} catch (err: any) {
			error = err.message || 'Failed to save user';
			console.error('Error saving user:', err);
		}
	}

	async function deleteUser(userId: string) {
		if (!confirm('Are you sure you want to delete this user?')) {
			return;
		}

		try {
			error = '';
			await pb.collection('users').delete(userId);
			await loadUsers();
		} catch (err: any) {
			error = err.message || 'Failed to delete user';
			console.error('Error deleting user:', err);
		}
	}

	function getRoleBadgeClass(role: string) {
		switch (role) {
			case 'admin':
				return 'bg-red-100 text-red-800';
			case 'monitor':
				return 'bg-blue-100 text-blue-800';
			case 'volunteer':
				return 'bg-green-100 text-green-800';
			default:
				return 'bg-gray-100 text-gray-800';
		}
	}

	function formatDate(dateString: string) {
		return new Date(dateString).toLocaleDateString();
	}
</script>

<div class="py-10">
	<div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
		<!-- Header -->
		<div class="mb-8 flex items-center justify-between">
			<div>
				<h1 class="text-3xl font-bold text-gray-900">{$t('user_management')}</h1>
				<p class="mt-2 text-sm text-gray-600">{$t('manage_users_description')}</p>
			</div>
			<button
				on:click={openAddModal}
				class="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:ring-offset-2"
			>
				<svg class="mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
				</svg>
				{$t('add_user')}
			</button>
		</div>

		<!-- Error Message -->
		{#if error}
			<div class="mb-4 rounded-md bg-red-50 p-4">
				<p class="text-sm text-red-800">{error}</p>
			</div>
		{/if}

		<!-- Users Table -->
		{#if loading}
			<div class="text-center py-12">
				<div class="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-indigo-600 border-r-transparent"></div>
				<p class="mt-2 text-sm text-gray-600">{$t('loading')}</p>
			</div>
		{:else if users.length === 0}
			<div class="text-center py-12">
				<svg
					class="mx-auto h-12 w-12 text-gray-400"
					fill="none"
					stroke="currentColor"
					viewBox="0 0 24 24"
				>
					<path
						stroke-linecap="round"
						stroke-linejoin="round"
						stroke-width="2"
						d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
					/>
				</svg>
				<h3 class="mt-2 text-sm font-medium text-gray-900">{$t('no_users')}</h3>
				<p class="mt-1 text-sm text-gray-500">{$t('get_started_by_creating_user')}</p>
			</div>
		{:else}
			<div class="overflow-hidden bg-white shadow sm:rounded-lg">
				<table class="min-w-full divide-y divide-gray-200">
					<thead class="bg-gray-50">
						<tr>
							<th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
								{$t('user')}
							</th>
							<th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
								{$t('mobile')}
							</th>
							<th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
								{$t('role')}
							</th>
							<th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
								{$t('status')}
							</th>
							<th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
								{$t('created')}
							</th>
							<th class="px-6 py-3 text-right text-xs font-medium uppercase tracking-wider text-gray-500">
								{$t('actions')}
							</th>
						</tr>
					</thead>
					<tbody class="divide-y divide-gray-200 bg-white">
						{#each users as user}
							<tr class="hover:bg-gray-50">
								<td class="whitespace-nowrap px-6 py-4">
									<div class="flex items-center">
										<div class="h-10 w-10 flex-shrink-0">
											<div class="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
												<span class="text-indigo-600 font-medium text-sm">
													{user.name ? user.name.charAt(0).toUpperCase() : user.email.charAt(0).toUpperCase()}
												</span>
											</div>
										</div>
										<div class="ml-4">
											<div class="text-sm font-medium text-gray-900">{user.name || 'No name'}</div>
											<div class="text-sm text-gray-500">{user.email}</div>
										</div>
									</div>
								</td>
								<td class="whitespace-nowrap px-6 py-4 text-sm text-gray-900">
									{user.mobile || '-'}
								</td>
								<td class="whitespace-nowrap px-6 py-4">
									<span class="inline-flex rounded-full px-2 text-xs font-semibold leading-5 {getRoleBadgeClass(user.role)}">
										{user.role}
									</span>
								</td>
								<td class="whitespace-nowrap px-6 py-4">
									{#if user.verified}
										<span class="inline-flex items-center rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-800">
											<svg class="mr-1 h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
												<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
											</svg>
											{$t('verified')}
										</span>
									{:else}
										<span class="inline-flex items-center rounded-full bg-yellow-100 px-2 py-1 text-xs font-medium text-yellow-800">
											<svg class="mr-1 h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
												<path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
											</svg>
											{$t('pending')}
										</span>
									{/if}
								</td>
								<td class="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
									{formatDate(user.created)}
								</td>
								<td class="whitespace-nowrap px-6 py-4 text-right text-sm font-medium">
									<button
										on:click={() => openEditModal(user)}
										class="mr-3 text-indigo-600 hover:text-indigo-900"
									>
										{$t('edit')}
									</button>
									<button
										on:click={() => deleteUser(user.id)}
										class="text-red-600 hover:text-red-900"
									>
										{$t('delete')}
									</button>
								</td>
							</tr>
						{/each}
					</tbody>
				</table>
			</div>
		{/if}
	</div>
</div>

<!-- Modal -->
{#if showModal}
	<div class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
		<div class="flex min-h-screen items-end justify-center px-4 pb-20 pt-4 text-center sm:block sm:p-0">
			<!-- Background overlay -->
			<div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" on:click={closeModal}></div>

			<!-- Modal panel -->
			<div class="relative inline-block transform overflow-hidden rounded-lg bg-white text-left align-bottom shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:align-middle z-50">
				<div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
					<h3 class="text-lg font-medium leading-6 text-gray-900 mb-4">
						{editingUser ? $t('edit_user') : $t('add_new_user')}
					</h3>

					{#if error}
						<div class="mb-4 rounded-md bg-red-50 p-3">
							<p class="text-sm text-red-800">{error}</p>
						</div>
					{/if}

					<div class="space-y-4">
						<!-- Email -->
						<div>
							<label for="email" class="block text-sm font-medium text-gray-700">{$t('email')}</label>
							<input
								type="email"
								id="email"
								bind:value={formEmail}
								class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border"
								required
							/>
						</div>

						<!-- Name -->
						<div>
							<label for="name" class="block text-sm font-medium text-gray-700">{$t('name')}</label>
							<input
								type="text"
								id="name"
								bind:value={formName}
								class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border"
							/>
						</div>

						<!-- Mobile -->
						<div>
							<label for="mobile" class="block text-sm font-medium text-gray-700">{$t('mobile')}</label>
							<input
								type="tel"
								id="mobile"
								bind:value={formMobile}
								placeholder="+1234567890"
								class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border"
							/>
						</div>

						<!-- Role -->
						<div class="relative">
							<label for="role" class="block text-sm font-medium text-gray-700">{$t('role')}</label>
							<select
								id="role"
								bind:value={formRole}
								class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border relative z-20"
							>
								{#each roles as role}
									<option value={role.value}>{role.label}</option>
								{/each}
							</select>
						</div>

						<!-- Password -->
						<div>
							<label for="password" class="block text-sm font-medium text-gray-700">
								{$t('password')} {editingUser ? '(' + $t('leave_blank_to_keep_current') + ')' : ''}
							</label>
							<input
								type="password" minlength="8"
								id="password"
								bind:value={formPassword}
								class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border"
								required={!editingUser}
							/>
						</div>

						<!-- Confirm Password -->
						{#if formPassword}
							<div>
								<label for="passwordConfirm" class="block text-sm font-medium text-gray-700">
									{$t('confirm_password')}
								</label>
								<input
									type="password" minlength="8"
									id="passwordConfirm"
									bind:value={formPasswordConfirm}
									class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border"
								/>
							</div>
						{/if}
					</div>
				</div>

				<div class="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
					<button
						type="button"
						on:click={saveUser}
						class="inline-flex w-full justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 sm:ml-3 sm:w-auto"
					>
						{editingUser ? $t('update') : $t('create')}
					</button>
					<button
						type="button"
						on:click={closeModal}
						class="mt-3 inline-flex w-full justify-center rounded-md bg-white px-4 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto"
					>
						{$t('cancel')}
					</button>
				</div>
			</div>
		</div>
	</div>
{/if}

